//Dhruvi Patel, Momoreoluwa Ayinde, Serena Havunen
//contains unimplemented methods that are implemented in the TicTacToe Class.
public interface TttInterface {

//sets up the buttons for the ttt board
	void buttonmethod();

	// checks to see if user has won
	void checkWinState();

}
